export const homePageLocators = {
    addRemoveButton: 'a[href="/add_remove_elements/"]',
    basicAuthButton: 'a[href="/basic_auth"]',
    brokenImagesButton: 'a[href="/broken_images"]'
}
export const addRemovePageLocators = {
    addElement: 'button[onclick = "addElement()"]',
    deleteElement: 'div#elements > :nth-child(1)',
    groupDeleteElements: 'div[id="elements"]'
}
export const brokenImages = {
    firstImage:'img[src="asdf.jpg"]',
    secondImage:'img[src="hjkl.jpg"]',
    thirdImage:'img[src="img/avatar-blank.jpg"]',
}