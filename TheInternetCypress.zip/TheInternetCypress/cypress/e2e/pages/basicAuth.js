import BasePage from "./basePage"

class basic_auth extends BasePage{
    constructor(){
        super();
    }
}

export default basic_auth;