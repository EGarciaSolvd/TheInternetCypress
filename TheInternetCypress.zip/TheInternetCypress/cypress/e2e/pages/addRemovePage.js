import { addRemovePageLocators } from "../locators/locators";
import basePage from "./basePage";

class AddRemovePage extends basePage{
    constructor(){
        super();
    }

    clickAddElementButton(){
        this.clickOnElement(addRemovePageLocators.addElement);
    }
    clickDeleteElementButton(){
        this.clickOnElement(addRemovePageLocators.deleteElement);
    }
}
export default AddRemovePage;