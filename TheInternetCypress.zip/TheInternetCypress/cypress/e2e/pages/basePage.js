class BasePage{
    navigate(url){
        Cypress.on('uncaught:exception',(err,Runnable) => {return false;})
        cy.visit(url)
    }
    clickOnElement(element){
        cy.get(element).click();
        cy.log('Element was clicked')
    }
}
export default BasePage;