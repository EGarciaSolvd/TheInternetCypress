import BasePage from "./basePage"

class brokenImages extends BasePage{
    constructor(){
        super();
    }
}

export default brokenImages;