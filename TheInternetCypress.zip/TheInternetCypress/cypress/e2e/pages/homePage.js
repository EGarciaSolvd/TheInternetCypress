import basePage from "./basePage";
import { homePageLocators } from "../locators/locators";

class HomePage extends basePage{
    constructor(){
        super();
    }

    clickAddRemoveButton(){
        this.clickOnElement(homePageLocators.addRemoveButton);
    }
    clickBasicAuthButton(){
        this.clickOnElement(homePageLocators.basicAuthButton);
    }
    clickBrokenImagesButton(){
        this.clickOnElement(homePageLocators.brokenImagesButton)
    }
}
export default HomePage;