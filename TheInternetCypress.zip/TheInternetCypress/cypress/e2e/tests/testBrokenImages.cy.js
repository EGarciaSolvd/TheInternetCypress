import HomePage from "../pages/homePage"
import { brokenImages } from "../locators/locators";

describe('Load images correctly', () => {
    let homePage = new HomePage;
    beforeEach('visit Homepage',() =>  (
        homePage.navigate(Cypress.env('url')),
        homePage.clickBrokenImagesButton()
      )
    )

    it('test successful load of image 1', () => {
        cy.get(brokenImages.firstImage).should('be.visible').should(($img) => {expect($img[0].naturalWidth).to.be.greaterThan(0)})
    })
    it('test successful load of image 2', () => {
        cy.get(brokenImages.secondImage).should('be.visible').should(($img) => {expect($img[0].naturalWidth).to.be.greaterThan(0)})
    })
    it('test successful load of image 3', () => {
        cy.get(brokenImages.thirdImage).should('be.visible').should(($img) => {expect($img[0].naturalWidth).to.be.greaterThan(0)})
    })
})