import HomePage from "../pages/homePage";
import { addRemovePageLocators } from "../locators/locators";

describe('The Home Page', () => {
  let homePage = new HomePage;

  beforeEach('visit Homepage',() =>  (
      homePage.navigate(Cypress.env('url'))
    )
  )
  it('goAddRemoveElements', () => {
    homePage.clickAddRemoveButton();
    cy.get(addRemovePageLocators.addElement).should('be.visible');
  })
})