import HomePage from "../pages/homePage";

describe('The Home Page', () => {
    let homePage = new HomePage;
  
    beforeEach('visit Homepage',() =>  (
        homePage.navigate(Cypress.env('url')),
        // homePage.clickBasicAuthButton()
        cy.get('a[href="/basic_auth"]').click()
      )
    )

    it('successful login', () => {
        // cy.window().then(function(p){
        //     cy.stub(p,'prompt').returns('Acceder')
        // })
        cy.on('window:confirm',(txt) => {
            expect(txt).to.contains('Acceder')
        })
    })
})