import HomePage from "../pages/homePage";
import AddRemovePage from "../pages/addRemovePage";
import { addRemovePageLocators } from "../locators/locators";

describe('Add/Remove elements', () => {
  let homePage = new HomePage;
  let addRemovePage = new AddRemovePage;

  beforeEach('visit Homepage',() =>  (
      homePage.navigate(Cypress.env('url'))
    )
  )

  it('test add elements',() => {
    let amountOfElements = 0;
    homePage.clickAddRemoveButton();
    for(let i=0;i<4;i++){
      addRemovePage.clickAddElementButton();
      cy.wait(1000);
      amountOfElements++;
    }
    
    cy.get(addRemovePageLocators.groupDeleteElements).find("*").should("have.length",amountOfElements)
})

it('test delete elements', () => {
  let amountOfElements = 0;
  let add = 4;
  let del = 2;
  
    homePage.clickAddRemoveButton();
    for(let i=0;i<add;i++){
      addRemovePage.clickAddElementButton();
      cy.wait(1000);
      amountOfElements++;
    }
    for(let i=0;i<del; i++){
      if(cy.get(addRemovePageLocators.deleteElement).should("be.visible")){
        addRemovePage.clickDeleteElementButton()
        amountOfElements--;
      }
    }
    
    cy.get(addRemovePageLocators.groupDeleteElements).find("*").should("have.length",amountOfElements)
})
})

